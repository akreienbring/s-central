/*
  Author: André Kreienbring
  A websocket server that handles all websocket activity. 
  Websocket clients can be the Shelly device outbound websocket, 
  the Dashboard application powered by React or the internal wsclient.

  If dashboard ws client ads a channelID to the message data, the 
  websocket connection is stored in an internal object
  that is used for subsequent communication with the client.

  The Shelly outbound websocket sends information that is used to
  update the device in memory and than forwarded to the Dashboard application.
*/
const prettyjson = require("prettyjson");
const config = require("config");
const shellyDevices = require("@devices/shellyDevices.js");
const shellyConnector = require("@devices/shellyConnector.js");

const updateDeviceValues = require("@src/utils/update-device-values.js");
const db = require("@db/db.js");
const wsUserHandler = require("./ws-user-handler.js");
const wsRoleHandler = require("./ws-role-handler.js");
const wsDeviceHandler = require("./ws-device-handler.js");
const wsNotificationHandler = require("./ws-notification-handler.js");
const wsBlogpostHandler = require("./ws-blogpost-handler.js");

/*
  An interval that pings the clients. If a client not responds it will be deleted
  from the internal list of ws clients
*/
const HEARTBEAT_INTERVAL = config.get("ws-server.ping-interval") * 1000; // ping interval in seconds
const HEARTBEAT_VALUE = 1;
const PING_MESSAGE = {
  event: "ping",
  data: {
    message: HEARTBEAT_VALUE,
  },
};

/* 
  When connected, the dashboard client sends a message. The websocket is then stored
  and managed with this object. The channelID property is used as the key
  in this object. The value is the websocket the client uses.
*/
const dashboardClients = {};

db.open();

/**
  Add a websocket to the internal list.
  The property name is the unique client name, the client has generated.
  The name either starts with the shelly device ID or with "View" followed
  by a random number.
  The ws is also considered as being alive.
  @param {object} ws The websocket to store. Must have an unique 'channelID' property
    to identify it.
*/
function addSocket(ws) {
  ws.isAlive = true;

  dashboardClients[ws.channelID] = ws;
  console.log(
    `wshandler: added socket ${ws.channelID}. Got ${
      Object.keys(dashboardClients).length
    } websockets`
  );
}

/**
  Delete a websocket from the internal list.
  The websocket is identified by the ID of the channel, that the client
  sends with his first message.
  If the channelID is undefined, the ws client doesn't require a permanent connection.
  @param {object} ws The websocket to delete. Must have an unique 'channelID' property
    to identify it.
*/
function deleteSocket(ws) {
  if (
    typeof ws.channelID !== "undefined" &&
    typeof dashboardClients[ws.channelID] !== "undefined"
  ) {
    delete dashboardClients[ws.channelID];
    console.log(
      `wshandler: deleted socket ${ws.channelID}. Got ${
        Object.keys(dashboardClients).length
      } websockets`
    );
  }
}

/**
  Receives messages from Shelly outbound websocket, the Dashboard application
  or the internal wsclient. The message was sent over the given websocket.
  Depending on the message properties actions are taken and answers are send.
  If a channelID exists, store the channel for later communication or deletion.
  The clients should respond with a pong to a ping to keep the websocket open.
  @param {object} msg The message that was send by a client.
  @param {object} ws The websocket that was used to send the message.
*/
function handleMessage(msg, ws) {
  //------------- Message Handling---------------------------
  if (typeof msg.src === "undefined") {
    if (typeof msg.data.channelID !== "undefined") {
      ws.channelID = msg.data.channelID;
      addSocket(ws);
    }
  }

  if (typeof msg.src !== "undefined") {
    /*
      Websocket message from a Shelly device.
      The device is identified by its Shelly ID, retrived from the internal list and 
      enriched with the websocket message from the Shelly.
      The updated device is forwarded to the Dashboard application
    */

    let device = shellyDevices.findDeviceById(msg.src);
    if (typeof device !== "undefined") {
      /* 
        Update the db with consumption data and get the current
        state of the switches ONLY if the NotifyFullStatus was
        requested from the device.
      */
      if (
        msg.method === "NotifyFullStatus" &&
        msg.dst === "request" &&
        typeof msg.params !== "undefined"
      ) {
        updateDeviceValues.update(device, msg.params);

        const newStable = msg.params.sys.available_updates?.stable?.version;
        const newBeta = msg.params.sys.available_updates?.beta?.version;

        delete device.rebootPending;

        if (
          (typeof device.online !== "undefined" && !device.online) ||
          device.name === "unknown" ||
          device.stable !== newStable ||
          device.beta !== newBeta ||
          (typeof device.updateStablePending !== "undefined" &&
            device.updateStablePending) ||
          (typeof device.updateBetaPending !== "undefined" &&
            device.updateBetaPending)
        ) {
          /*
            Reload an offline device because it's obviously online.
            If an update is pending, the device will be reloaded
            to get the current firmware of the device.
            If stable or beta update has changed, the device was updated outside of this app.
          */
          device.online = true;

          console.warn(`Reloading device ${device.cname}`);
          shellyDevices.getDevice(device.ip, true).then((reloadedDevice) => {
            // prettyjson.render(reloadedDevice);
            if (
              (device.updateStablePending || device.updateSBetaPending) &&
              reloadedDevice.fw_id === device.old_fw_id
            ) {
              console.warn(
                `Reloaded device ${reloadedDevice.cname}. Firmware is still the same (${device.old_fw_id}).`
              );
              return; // keep the pending update flags until the firmware is updated
            } else {
              console.log(
                `Firmaware update of ${device.cname} was successfull!`
              );
            }

            console.log(`Device ${device.cname} was reloaded.`);

            device = reloadedDevice;
            // TODO: check if the next three lines are necessary
            delete device.updateBetaPending;
            delete device.updateStablePending;
            delete device.old_fw_id;

            const reloadMessage = {
              event: "ShellyUpdate",
              type: "device",
              data: {
                source: "WSHandler",
                message: "Device was reloaded",
                device,
                subscriptionID: msg.src,
              },
            };
            broadcast(reloadMessage);
          });
          // don't send any message to the client if an update is pending
          return;
        }
      }

      if (
        ((msg.dst === "ws" && msg.method !== "NotifyFullStatus") ||
          (msg.dst === "request" && msg.method === "NotifyFullStatus")) &&
        typeof msg.params !== "undefined"
      ) {
        /*
          Only forward requested NotifyFullStatus or
          other messages (NotifyStatus, NotifyEvent...) directly send by the device,
        */
        device.wsmessages[msg.method] = msg;

        const updateMessage = {
          event: "ShellyUpdate",
          type: "ws",
          data: {
            source: "WSHandler",
            message: "new WS message",
            device: device,
            subscriptionID: msg.src,
          },
        };
        broadcast(updateMessage);
      }
    } else {
      console.error(`wshandler: Couldn't find device with id ${msg.src}`);
    }
  } else if (typeof msg.event !== "undefined") {
    // message from dashboard client, endpoint or loghandler
    if (msg.event === "user reconnect") {
      // Send after a client tried to reconnect.
      msg.data.message =
        typeof msg.data.secret !== "undefined"
          ? "OK, will reconnect you!"
          : "Couldn't reconnect you";
      ws.send(JSON.stringify(msg));
    } else if (msg.event === "ShellyUpdate") {
      // message from Loghandler or enpoint is simply forwarded to all clients
      msg.data.subscriptionID = msg.data.device.id;
      broadcast(msg);
    } else if (msg.event === "pong" && msg.data.message === HEARTBEAT_VALUE) {
      // the client answered to a ping message
      ws.isAlive = true;
    } else if (msg.event.startsWith("getTimeline")) {
      /*
        If the Dashboard receives a websocket message from a Shelly device 
        (eg. NotifyStatus) it will ask for timeline data to print a chart.
        This data is fetched from the database and sent to the client.
      */
      const answer = {
        event: msg.event,
        data: {
          source: "WSHandler",
          message: `OK! ${msg.event}`,
          requestID: msg.data.requestID,
        },
      };
      if (msg.event === "getTimelineMinute") {
        answer.data.rows = db.select("cByMinute", [], [], [], null, "ts");
      } else if (msg.event === "getTimelineHour") {
        answer.data.rows = db.select("cByHour", [], [], [], null, "ts");
      } else if (msg.event === "getTimelineDay") {
        answer.data.rows = db.select("cByDay", [], [], [], null, "ts");
      } else if (msg.event === "getTimelineMonth") {
        answer.data.rows = db.select("cByMonth", [], [], [], null, "ts");
      } else if (msg.event === "getTimelineYear") {
        answer.data.rows = db.select("cByYear", [], [], [], null, "ts");
      }
      if (typeof answer.data.rows !== "undefined") {
        ws.send(JSON.stringify(answer));
      }
    } else if (msg.event === "toggleSwitch") {
      shellyConnector.toggleSwitch(
        shellyDevices.findDeviceByIp(msg.data.switch.deviceIp),
        msg.data.switch
      );
    } else if (msg.event === "setSwitch") {
      shellyConnector.setSwitch(
        shellyDevices.findDeviceByIp(msg.data.switch.deviceIp),
        msg.data.switch
      );
    } else if (msg.event.startsWith("user")) {
      wsUserHandler.handle(msg, ws);
    } else if (msg.event.startsWith("role")) {
      wsRoleHandler.handle(msg, ws);
    } else if (msg.event.startsWith("device")) {
      wsDeviceHandler.handle(msg, ws);
    } else if (msg.event.startsWith("notification")) {
      if (msg.event === "notification create") {
        // handle notifications created by the server
        let notification = msg.data.notification;

        if (notification.type === "script-error") {
          /* 
            Loghandler has detected a Script error.
          */
          const script = shellyDevices.findScript(
            notification.device_ip,
            notification.script_id
          );

          if (typeof script !== "undefined") {
            notification = {
              type: notification.type,
              title: `Error: ${notification.device_cname}, Script: ${script.name}`,
              device_ip: notification.device_ip,
              device_cname: notification.device_cname,
              script_id: notification.script_id,
              script_name: script.name,
              notification: notification.notification,
              isUnread: 1,
              ts: Date.now(),
            };

            info = db.insert("notifications", notification, true);

            // use the row id to identify the notification when it's been deleted
            notification.id = info.lastInsertRowid;
            msg.data.notification = notification;
            broadcast(msg);
          } else {
            console.error(
              `Couldn't store a notification. Script with id ${notification.scrip_id} on device ${notification.device_cname} does not exist!`
            );
          }
        } else if (notification.type === "device-offline") {
          // endpoint was called
          notification = {
            type: notification.type,
            title: `Info: ${notification.device_cname} is offline`,
            device_ip: notification.device_ip,
            device_cname: notification.device_cname,
            script_id: null,
            script_name: null,
            notification: notification.notification,
            isUnread: 1,
            ts: Date.now(),
          };

          info = db.insert("notifications", notification, true);

          notification.id = info.lastInsertRowid;
          msg.data.notification = notification;
          broadcast(msg);
        }
      } else {
        // handle notifications requests created by the client
        wsNotificationHandler.handle(msg, ws);
      }
    } else if (msg.event.startsWith("blog")) {
      wsBlogpostHandler.handle(msg, ws);
    } else {
      console.log(
        "wshandler: received unhandled message (event unknown): " +
          prettyjson.render(msg)
      );
    }
  } else {
    // Unidentified message will just be logged to the console
    console.log(
      "wshandler: received unhandled message (no event, no src): " +
        prettyjson.render(msg)
    );
  }
}

/**
  Called when the connection to a client was opened. 
  The socket will be stored in the internal list, when the first message is received.
  @param {object} ws The websocket connection
*/
function handleOpen(ws) {
  // console.log("wshandler: Connection was opened");
}

/**
  Called when the connection to a client was closed.
  Sets the maintained websocket connection to null
  @param {object} event has information over the connection
  @param {object} ws The websocket connection
*/
function handleClose(event, ws) {
  console.log(
    `wshandler: Connection was closed. Code: ${event.code} Reason: ${event.reason}`
  );
  // remove the socket from the internal list
  deleteSocket(ws);
}

/**
  Send a message to all connected clients.
  As there may be more than one frontend running in the local network.
  @param {object} message The message that will be send to all managed clients.
*/
function broadcast(message) {
  // eslint-disable-next-line no-unused-vars
  Object.entries(dashboardClients).forEach(([channelID, ws]) => {
    if (typeof ws !== "undefined" && ws !== null) {
      //console.log(`Broadcasting to channelID ${channelID}`);
      ws.send(JSON.stringify(message));
    }
  });
}

/*
  This interval sends a ping to all clients. The client is set to inactive and
  will reactivated when message with a pong arrives.
  If a ws client doesn't respond within the configured time, the websocket is deleted.
*/
if (HEARTBEAT_INTERVAL > 0) {
  console.log(`Sending ping to all managed clients`);
  setInterval(() => {
    // eslint-disable-next-line no-unused-vars
    Object.entries(dashboardClients).forEach(([channelID, ws]) => {
      if (typeof ws !== "undefined" && ws !== null) {
        if (!ws.isAlive) {
          ws.close(1000, "Did not receive a pong!");
          deleteSocket(ws);
        }

        ws.isAlive = false;
        // console.log(`Sending PING to ${channelID}`);
        ws.send(JSON.stringify(PING_MESSAGE));
      }
    });
  }, HEARTBEAT_INTERVAL);
}

module.exports = { handleMessage, handleClose, handleOpen };
